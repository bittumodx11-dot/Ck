import { BiodataData, ResumeData, BiodataSectionItem } from '../types';

export interface BiodataPageSection {
  id: string;
  type: string;
  title: string;
  items?: any[];
  isContinuation?: boolean;
  content?: any;
}

export interface BiodataPageData {
  pageIndex: number;
  totalPages: number;
  showHeader: boolean;
  sections: BiodataPageSection[];
  showDeclaration: boolean;
}

export interface ResumePageSection {
  id: string;
  type: 'summary' | 'experience' | 'education' | 'skills' | 'projects' | 'languages' | 'certifications';
  title: string;
  items?: any[];
  content?: string;
}

export interface ResumePageData {
  pageIndex: number;
  totalPages: number;
  showHeader: boolean;
  sections: ResumePageSection[];
}

/**
 * Calculate usable page height in pixels for an A4 sheet (794px x 1123px at 96 DPI)
 */
export function getUsablePageHeight(
  pageMargins: 'narrow' | 'normal' | 'wide' = 'normal'
): number {
  const TOTAL_A4_HEIGHT = 1123;
  // Account for padding (top + bottom) and page numbering footer (~24px)
  const paddingMap = {
    narrow: 40 + 24, // 20px top, 20px bottom + footer
    normal: 64 + 24, // 32px top, 32px bottom + footer
    wide: 96 + 24,   // 48px top, 48px bottom + footer
  };
  return TOTAL_A4_HEIGHT - (paddingMap[pageMargins] || paddingMap.normal);
}

/**
 * Content-Aware Paginate Biodata / CV Data into discrete A4 Pages
 */
export function paginateBiodataData(data: BiodataData): BiodataPageData[] {
  const usableHeight = getUsablePageHeight(data.pageMargins);
  
  // Header height on Page 1
  let headerHeight = 0;
  if (data.showDocumentTitle) headerHeight += 60;
  headerHeight += 120; // Profile Name, Contact Info, Photo
  
  // Declaration & Signature block height
  const declarationHeight = data.includeDeclaration ? 130 : 0;

  // Check forced layout modes
  if (data.pageLayout === '1-page' || data.autoFitOnePage) {
    // Single page mode: All enabled sections on 1 page
    const enabledSections: BiodataPageSection[] = data.sections
      .filter((sec) => sec.enabled)
      .map((sec) => ({
        id: sec.id,
        type: sec.type,
        title: sec.title,
      }));

    return [
      {
        pageIndex: 1,
        totalPages: 1,
        showHeader: true,
        sections: enabledSections,
        showDeclaration: data.includeDeclaration,
      },
    ];
  }

  if (data.pageLayout === '2-pages') {
    // Forced 2-Page distribution: Page 1 gets Personal + Education; Page 2 gets Experience, Skills, Family, About, Declaration
    const enabled = data.sections.filter((sec) => sec.enabled);
    const page1Sections: BiodataPageSection[] = [];
    const page2Sections: BiodataPageSection[] = [];

    enabled.forEach((sec) => {
      if (sec.type === 'personal' || sec.type === 'education') {
        page1Sections.push({ id: sec.id, type: sec.type, title: sec.title });
      } else {
        page2Sections.push({ id: sec.id, type: sec.type, title: sec.title });
      }
    });

    // Fallback if page 1 sections are empty
    if (page1Sections.length === 0 && page2Sections.length > 0) {
      page1Sections.push(page2Sections.shift()!);
    }

    return [
      {
        pageIndex: 1,
        totalPages: 2,
        showHeader: true,
        sections: page1Sections,
        showDeclaration: false,
      },
      {
        pageIndex: 2,
        totalPages: 2,
        showHeader: false,
        sections: page2Sections,
        showDeclaration: data.includeDeclaration,
      },
    ];
  }

  // Dynamic Auto Pagination ('auto' mode)
  const pages: BiodataPageData[] = [];
  let currentPageIndex = 1;
  let currentPageUsedHeight = headerHeight;
  let currentSections: BiodataPageSection[] = [];

  const enabledSections = data.sections.filter((sec) => sec.enabled);

  for (const sec of enabledSections) {
    let sectionHeight = 30; // Title height

    if (sec.type === 'personal') {
      const activeFields = data.personalFields.filter((f) => f.enabled);
      sectionHeight += Math.ceil(activeFields.length / 2) * 24;
    } else if (sec.type === 'education') {
      sectionHeight += data.education.length * 48;
    } else if (sec.type === 'experience') {
      sectionHeight += data.experience.reduce((acc, exp) => {
        const descLines = exp.description ? Math.ceil(exp.description.length / 60) : 1;
        return acc + 40 + descLines * 16;
      }, 0);
    } else if (sec.type === 'skills') {
      sectionHeight += 40;
    } else if (sec.type === 'languages') {
      sectionHeight += data.languagesDetailed ? data.languagesDetailed.length * 24 : 40;
    } else if (sec.type === 'family') {
      const activeFam = data.familyFields ? data.familyFields.filter((f) => f.enabled) : [];
      sectionHeight += activeFam.length * 24 + (data.aboutFamily ? 30 : 0);
    } else if (sec.type === 'about') {
      const lines = data.aboutMe ? Math.ceil(data.aboutMe.length / 70) : 2;
      sectionHeight += lines * 18 + 10;
    } else if (sec.type === 'hobbies') {
      sectionHeight += 35;
    } else {
      sectionHeight += 50;
    }

    // Does this section fit on the current page?
    if (currentPageUsedHeight + sectionHeight <= usableHeight) {
      currentSections.push({ id: sec.id, type: sec.type, title: sec.title });
      currentPageUsedHeight += sectionHeight + 12; // 12px section gap
    } else {
      // If it doesn't fit and we already have sections on this page, push current page and start new one
      if (currentSections.length > 0) {
        pages.push({
          pageIndex: currentPageIndex,
          totalPages: 0, // updated after loop
          showHeader: currentPageIndex === 1,
          sections: [...currentSections],
          showDeclaration: false,
        });

        currentPageIndex++;
        currentSections = [];
        currentPageUsedHeight = 0; // Header is only on Page 1
      }

      // Add section to new page
      currentSections.push({ id: sec.id, type: sec.type, title: sec.title });
      currentPageUsedHeight += sectionHeight + 12;
    }
  }

  // Check declaration placement
  let declarationOnLastPage = false;
  if (data.includeDeclaration) {
    if (currentPageUsedHeight + declarationHeight <= usableHeight) {
      declarationOnLastPage = true;
    } else {
      // Push current page without declaration, then create new page for declaration
      if (currentSections.length > 0) {
        pages.push({
          pageIndex: currentPageIndex,
          totalPages: 0,
          showHeader: currentPageIndex === 1,
          sections: [...currentSections],
          showDeclaration: false,
        });

        currentPageIndex++;
        currentSections = [];
        currentPageUsedHeight = 0;
      }
      declarationOnLastPage = true;
    }
  }

  // Push remaining page
  if (currentSections.length > 0 || declarationOnLastPage) {
    pages.push({
      pageIndex: currentPageIndex,
      totalPages: 0,
      showHeader: currentPageIndex === 1,
      sections: currentSections,
      showDeclaration: declarationOnLastPage && data.includeDeclaration,
    });
  }

  // Fallback to at least 1 page
  if (pages.length === 0) {
    pages.push({
      pageIndex: 1,
      totalPages: 1,
      showHeader: true,
      sections: [],
      showDeclaration: data.includeDeclaration,
    });
  }

  // Set totalPages on all pages
  const finalTotalPages = pages.length;
  return pages.map((p) => ({ ...p, totalPages: finalTotalPages }));
}

/**
 * Content-Aware Paginate Resume Data into discrete A4 Pages
 */
export function paginateResumeData(data: ResumeData): ResumePageData[] {
  const usableHeight = getUsablePageHeight();

  if (data.pageLayout === '1-page' || data.autoFitOnePage) {
    return [
      {
        pageIndex: 1,
        totalPages: 1,
        showHeader: true,
        sections: [
          { id: 'summary', type: 'summary', title: 'Professional Profile' },
          { id: 'experience', type: 'experience', title: 'Work Experience' },
          { id: 'education', type: 'education', title: 'Education' },
          { id: 'skills', type: 'skills', title: 'Key Skills & Technologies' },
          { id: 'projects', type: 'projects', title: 'Key Projects' },
        ],
      },
    ];
  }

  if (data.pageLayout === '2-pages') {
    return [
      {
        pageIndex: 1,
        totalPages: 2,
        showHeader: true,
        sections: [
          { id: 'summary', type: 'summary', title: 'Professional Profile' },
          { id: 'experience', type: 'experience', title: 'Work Experience' },
        ],
      },
      {
        pageIndex: 2,
        totalPages: 2,
        showHeader: false,
        sections: [
          { id: 'education', type: 'education', title: 'Education' },
          { id: 'skills', type: 'skills', title: 'Key Skills & Technologies' },
          { id: 'projects', type: 'projects', title: 'Key Projects' },
        ],
      },
    ];
  }

  // Dynamic Auto Mode
  let headerHeight = 110;
  let currentHeight = headerHeight;
  let currentSections: ResumePageSection[] = [];
  const pages: ResumePageData[] = [];
  let pageIndex = 1;

  const sectionsToProcess: ResumePageSection[] = [
    { id: 'summary', type: 'summary', title: 'Professional Profile' },
    { id: 'experience', type: 'experience', title: 'Work Experience' },
    { id: 'education', type: 'education', title: 'Education' },
    { id: 'skills', type: 'skills', title: 'Key Skills & Technologies' },
    { id: 'projects', type: 'projects', title: 'Key Projects' },
  ];

  for (const sec of sectionsToProcess) {
    let secHeight = 30;
    if (sec.type === 'summary' && data.summary) {
      secHeight += Math.ceil(data.summary.length / 70) * 18;
    } else if (sec.type === 'experience' && data.experience) {
      secHeight += data.experience.reduce((acc, exp) => {
        const descLines = exp.description ? Math.ceil(exp.description.length / 60) : 1;
        return acc + 35 + descLines * 16;
      }, 0);
    } else if (sec.type === 'education' && data.education) {
      secHeight += data.education.length * 40;
    } else if (sec.type === 'skills' && data.skills) {
      secHeight += Math.ceil(data.skills.length / 4) * 28;
    } else if (sec.type === 'projects' && data.projects) {
      secHeight += data.projects.reduce((acc, proj) => {
        const descLines = proj.description ? Math.ceil(proj.description.length / 60) : 1;
        return acc + 35 + descLines * 16;
      }, 0);
    }

    if (secHeight <= 30) continue; // Skip empty section

    if (currentHeight + secHeight <= usableHeight) {
      currentSections.push(sec);
      currentHeight += secHeight + 12;
    } else {
      if (currentSections.length > 0) {
        pages.push({
          pageIndex,
          totalPages: 0,
          showHeader: pageIndex === 1,
          sections: [...currentSections],
        });
        pageIndex++;
        currentSections = [];
        currentHeight = 0;
      }
      currentSections.push(sec);
      currentHeight += secHeight + 12;
    }
  }

  if (currentSections.length > 0) {
    pages.push({
      pageIndex,
      totalPages: 0,
      showHeader: pageIndex === 1,
      sections: currentSections,
    });
  }

  if (pages.length === 0) {
    pages.push({
      pageIndex: 1,
      totalPages: 1,
      showHeader: true,
      sections: sectionsToProcess,
    });
  }

  const totalPages = pages.length;
  return pages.map((p) => ({ ...p, totalPages }));
}

/**
 * Regression Test Dataset for Multi-Page Content Testing
 */
export const MULTI_PAGE_REGRESSION_TEST_BIODATA: Partial<BiodataData> = {
  documentTitle: 'CURRICULUM VITAE (REGRESSION TEST)',
  subtitle: 'Comprehensive Multi-Page Verification Document',
  
  personalFields: [
    { id: 'fullName', label: 'Full Name', value: 'Tanvir Ahmed Mazumder (তানভীর আহমেদ মজুমদার)', enabled: true },
    { id: 'fatherName', label: "Father's Name", value: 'Late Mahbubur Rahman Mazumder', enabled: true },
    { id: 'motherName', label: "Mother's Name", value: 'Begum Rokeya Mazumder', enabled: true },
    { id: 'dob', label: 'Date of Birth', value: '1995-11-24', enabled: true },
    { id: 'gender', label: 'Gender', value: 'Male (পুরুষ)', enabled: true },
    { id: 'maritalStatus', label: 'Marital Status', value: 'Unmarried (অবিবাহিত)', enabled: true },
    { id: 'nationality', label: 'Nationality', value: 'Bangladeshi / Indian', enabled: true },
    { id: 'religion', label: 'Religion', value: 'Islam (ইসলাম)', enabled: true },
    { id: 'bloodGroup', label: 'Blood Group', value: 'B+ (Positive)', enabled: true },
    { id: 'phone', label: 'Phone Number', value: '+880 1711-908234 / +91 98301-22910', enabled: true },
    { id: 'email', label: 'Email Address', value: 'tanvir.mazumder.official@gmail.com', enabled: true },
    { id: 'address', label: 'Present Address', value: 'House 42, Road 11, Block D, Banani, Dhaka-1213 / Park Circus, Kolkata WB', enabled: true },
  ],

  education: [
    {
      id: 'edu1',
      qualification: 'Master of Science (M.Sc) in Computer Science & Engineering',
      institution: 'Bangladesh University of Engineering and Technology (BUET)',
      boardUniversity: 'BUET Academic Council',
      year: '2019',
      percentageGrade: 'CGPA 3.92 out of 4.00 (Distinction)',
    },
    {
      id: 'edu2',
      qualification: 'Bachelor of Science (B.Sc) in Computer Science & Technology',
      institution: 'Dhaka University (DU) / Heritage Institute of Technology',
      boardUniversity: 'University of Dhaka / MAKAUT',
      year: '2017',
      percentageGrade: 'CGPA 3.88 out of 4.00 (First Class First)',
    },
    {
      id: 'edu3',
      qualification: 'Higher Secondary Certificate (HSC - Science)',
      institution: 'Notre Dame College, Dhaka',
      boardUniversity: 'Dhaka Education Board',
      year: '2013',
      percentageGrade: 'GPA 5.00 out of 5.00 (Golden A+)',
    },
    {
      id: 'edu4',
      qualification: 'Secondary School Certificate (SSC - Science)',
      institution: 'Government Laboratory High School, Dhaka',
      boardUniversity: 'Dhaka Education Board',
      year: '2011',
      percentageGrade: 'GPA 5.00 out of 5.00 (Golden A+)',
    },
  ],

  experience: [
    {
      id: 'exp1',
      company: 'Brain Station 23 / Lead Software Architect',
      position: 'Staff Software Architect & Tech Lead',
      startDate: 'Jan 2021',
      endDate: 'Present',
      description:
        'Directing cloud-native enterprise application development, distributed database clustering, microservices performance optimization, and mentoring senior engineering teams across South Asia.',
    },
    {
      id: 'exp2',
      company: 'Samsung R&D Institute / Senior Software Engineer',
      position: 'Senior Software Engineer (Mobile & Cloud Systems)',
      startDate: 'Jul 2018',
      endDate: 'Dec 2020',
      description:
        'Architected real-time asynchronous document parsing engines, multi-thread canvas rendering modules, and secure client-side cryptographic storage integrations.',
    },
    {
      id: 'exp3',
      company: 'Kona Software Lab / Junior Systems Engineer',
      position: 'Systems & Algorithm Engineer',
      startDate: 'Jan 2017',
      endDate: 'Jun 2018',
      description:
        'Implemented high-throughput data processing algorithms, PDF rendering primitives, and UTF-8 Bengali Unicode font parser routines.',
    },
  ],

  aboutMe:
    'I am a passionate software engineer with over 7 years of hands-on experience building scalable applications. I specialize in document rendering systems, clean architecture, and localized user interfaces in Bengali and English. (আমি একজন প্রফেশনাল সফটওয়্যার প্রকৌশলী যিনি দীর্ঘ ৭ বছর ধরে আধুনিক ওয়েব অ্যাপ্লিকেশন এবং ডকুমেন্ট অটোমেশন সিস্টেমে কাজ করছেন।)',

  aboutFamily:
    'Highly respectable educational background and culturally rooted Sunni Muslim family with strong ethics. (আমাদের পরিবার একটি সুশিক্ষিত, মার্জিত ও সম্ভ্রান্ত মুসলিম পরিবার।)',

  includeDeclaration: true,
  declarationText:
    'I hereby solemnly affirm and declare that all statements made in this curriculum vitae are true, complete and correct to the best of my knowledge and belief. (আমি সজ্ঞানে ঘোষণা করছি যে উপরে প্রদত্ত সকল বিবরণ সম্পূর্ণ সত্য ও সঠিক।)',
  place: 'Dhaka / Kolkata',
  date: new Date().toLocaleDateString('en-GB'),
  showDate: true,
  signatureType: 'type',
  signatureText: 'Tanvir Ahmed Mazumder',
  applicantName: 'Tanvir Ahmed Mazumder',
  showApplicantName: true,
  pageLayout: 'auto',
  autoFitOnePage: false,
};
